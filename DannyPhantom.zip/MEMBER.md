13510011 	Danny Andrianto 			danny_andrianto@hotmail.com		dhanui
13510103 	Johannes Ridho Tumpuan P	13510103@std.stei.itb.ac.id		13510103
13510061	Muhammad Sohibul Maromi		msmaromi@gmail.com				msmaromi
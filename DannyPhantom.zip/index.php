<?php
header("location:src/index.php");
?>
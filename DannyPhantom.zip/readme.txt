Web service yang digunakan adalah Appfog

Kami membuat dua app yaitu server SOAP dan server REST
Server SOAP: soap.ap01.aws.af.cm
Server REST: phprestsql.ap01.aws.af.cm
Kedua server tersebut dibind ke sebuah mysql service yang menyimpan basis data